﻿using System;
using System.Collections.Specialized;
using System.IO;
using System.Net;
using System.Net.WebSockets;
using System.Security.Principal;
using System.Text;
using System.Web;
using System.Web.Hosting;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.SessionState;
using System.Web.UI;
using dk.nita.saml20.protocol.pages;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using OiOSaml.RealMe.Protocol;

namespace OiOSaml.RealMe.Tests
{

    [TestClass]
    public class UnitTest1
    {

        [TestMethod]
        public void TestMethod1()
        {
            var url = "https://dev-easy.cloudapp.net/oiosaml-net.dk/login.ashx?ReturnUrl=%2foiosaml-net.dk%2fMyPage.aspx";
            string body = "Oren";

            var sw = new StringWriter();
            SimpleWorkerRequest request = new SimpleWorkerRequest(
                "/oiosaml-net.dk",
                @"C:\Users\hassidi\Documents\Visual Studio 2015\Projects\Easy Software\OiOSaml\OiOSaml2011\WebsiteDemo\",
                "login.ashx",
                "ReturnUrl=%2foiosaml-net.dk%2fMyPage.aspx",
                sw);

            HttpContext.Current = new HttpContext(request);

            try
            {
                var handler = new RealMeSaml20SignonHandler();
                handler.ProcessRequest(HttpContext.Current);
            }
            catch (System.ArgumentNullException eArgumentNull)
            {
                Console.WriteLine(eArgumentNull);

                if (eArgumentNull.Message != "Value cannot be null.\r\nParameter name: basepath")
                {
                    throw eArgumentNull;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

        }





    }
}
