﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OiOSaml.RealMe.WebApp.Models;

namespace OiOSaml.RealMe.WebApp.Controllers
{
    [Authorize]
    public class SecureAreaController : Controller
    {
        [AllowAnonymous]
        public ActionResult SecureArea()
        {
            return View(new SecureAreaViewModel());
        }

        
    }
}