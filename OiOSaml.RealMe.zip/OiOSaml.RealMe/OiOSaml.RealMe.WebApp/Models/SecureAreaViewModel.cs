﻿using System.Security.Claims;
using OiOSaml.RealMe.Identity;

namespace OiOSaml.RealMe.WebApp.Models
{
    public class SecureAreaViewModel
    {
        public RealMeIdentity RealMeIdentity => new RealMeIdentity();

        public ClaimsIdentity ClaimsIdentity => RealMeIdentity.ClaimsIdentity;


    }
}