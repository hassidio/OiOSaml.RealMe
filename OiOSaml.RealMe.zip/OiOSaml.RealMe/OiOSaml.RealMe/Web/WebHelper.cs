using System;
using System.Text;
using System.Web;
using dk.nita.saml20.config;
using dk.nita.saml20.protocol;
using OiOSaml.RealMe.Identity;

namespace OiOSaml.RealMe.Web
{
    public class WebHelper
    {
        public static string GetIdpLoginPath(string dynamicReturnPath, string issuer, string authenticationType)
        {
            var localLoginPath = SAML20FederationConfig.GetConfig().ServiceProvider.SignOnEndpoint.localPath;

            localLoginPath = string.Format("http://temp{0}", localLoginPath);

            var builder = new UriBuilder(localLoginPath);

            // The port number defines the protocol port for contacting the host referenced in the URI.
            // If a port is not specified as part of the URI, the Port property returns the value of - 1 
            // to indicate that the default port value for the protocol scheme will be used to connect to 
            // the host.If the Port property is set to a value of - 1, this indicates that the default port value 
            // for the protocol scheme will be used to connect to the host.
            builder.Port = -1;

            var query = HttpUtility.ParseQueryString(builder.Query);

            if (!string.IsNullOrEmpty(dynamicReturnPath))
                query["ReturnUrl"] = dynamicReturnPath;

            if (!string.IsNullOrEmpty(issuer))
                query[Saml20AbstractEndpointHandler.IDPChoiceParameterName] = issuer;

            if (!string.IsNullOrEmpty(authenticationType))
                query["wauth"] = authenticationType;

            builder.Query = query.ToString();

            return $"{builder.Path}{builder.Query}"; ;
        }

        public static RealMeIdentity GetRealMeIdentity()
        {
            return new RealMeIdentity();
        }

        public static string EncodeToBase64UrlSafe(string str)
        {
            if (str == null || str == "")
            {
                return null;
            }

            byte[] bytesToEncode = System.Text.UTF8Encoding.UTF8.GetBytes(str);
            String returnVal = System.Convert.ToBase64String(bytesToEncode);

            return returnVal.TrimEnd('=').Replace('+', '-').Replace('/', '_');
        }

        public static string DecodeFromBase64UrlSafe(string str)
        {
            if (string.IsNullOrEmpty(str)) return null;

            var incoming = str.Replace('_', '/').Replace('-', '+');

            switch (str.Length % 4)
            {
                case 2: incoming += "=="; break;
                case 3: incoming += "="; break;
            }

            var bytes = Convert.FromBase64String(incoming);

            var txt = Encoding.ASCII.GetString(bytes);

            return txt;
        }
    }
}