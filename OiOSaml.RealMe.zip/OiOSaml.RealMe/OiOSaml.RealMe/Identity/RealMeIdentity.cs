using System.Security.Claims;
using System.Security.Principal;
using dk.nita.saml20.identity;
using dk.nita.saml20.Schema.Core;
using Microsoft.AspNet.Identity;
using OiOSaml.RealMe.Web;

namespace OiOSaml.RealMe.Identity
{
    public class RealMeIdentity
    {
        public IIdentity CurrentIdentity =>
            Saml20Identity.Current != null ? Saml20Identity.Current : new GenericIdentity("");

        public bool IsAuthenticatedUser =>  CurrentIdentity.IsAuthenticated;


        public string Name => CurrentIdentity.Name;

        public SamlAttribute IvsAssertionIdentity =>
            GetAttribute("urn:nzl:govt:ict:stds:authn:safeb64:attribute:igovt:IVS:Assertion:Identity");

        public SamlAttribute FIT =>
            GetAttribute("urn:nzl:govt:ict:stds:authn:attribute:igovt:IVS:FIT");

        public string IvsAssertionIdentityDecoded =>
            WebHelper.DecodeFromBase64UrlSafe(IvsAssertionIdentity.AttributeValue[0]);


        public ClaimsIdentity ClaimsIdentity => new ClaimsIdentity(
            new[] {
                new Claim(ClaimTypes.NameIdentifier, Name),
                new Claim("http://schemas.microsoft.com/accesscontrolservice/2010/07/claims/identityprovider", "ASP.NET Identity", "http://www.w3.org/2001/XMLSchema#string"),

                new Claim(ClaimTypes.Name, Name),

                new Claim(IvsAssertionIdentity.Name, IvsAssertionIdentity.AttributeValue[0]),
                new Claim(FIT.Name, FIT.AttributeValue[0]),

            },
            DefaultAuthenticationTypes.ApplicationCookie);

        private SamlAttribute GetAttribute(string urn)
        {
            var identityType = CurrentIdentity.GetType();

            return identityType == typeof(Saml20Identity) && ((Saml20Identity)CurrentIdentity).HasAttribute(urn)
                ? ((Saml20Identity)CurrentIdentity)[urn][0]
                : null;
        }

    }

    public class Party
    {
        public PartyName PartyName { get; set; }

        public string PersonInfo { get; set; }

        public BirthInfo BirthInfo { get; set; }

    }

    public class BirthInfo
    {
    }

    public class PartyName
    {
        public PersonName PersonName { get; set; }
         
    }

    public class PersonName
    {
        public NameElement FirstName { get; set; }
        public NameElement MiddleName { get; set; }
        public NameElement LastName { get; set; }
    }

    public class NameElement
    {
        public string ElementValue { get; set; }
        public string ElementType { get; set; }

    }
}