using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;


namespace OiOSaml.RealMe.Configuration
{
    /// <summary>
    /// Common federation parameters container - used by federation initiators to populate the intended authentication context 
    /// in a saml assertion and by federation receivers 
    /// </summary>
    public class OiOSamlRealMeFederationConfig : ConfigurationSection
    {
        /// <summary>
        /// RealMe Services Element
        /// </summary>
        [ConfigurationProperty("services", IsDefaultCollection = false)]
        [ConfigurationCollection(typeof(RealMeServiceCollection),
            AddItemName = "add",
            ClearItemsName = "clear",
            RemoveItemName = "remove")]
        public RealMeServiceCollection RealMeServiceCollectionElement
        {
            get { return (RealMeServiceCollection) base["services"]; }
        }

        public static OiOSamlRealMeFederationConfig Config
        {
            get { return (OiOSamlRealMeFederationConfig) ConfigurationManager.GetSection("oiosaml.realme"); }
        }
    }

    /// <summary>
    /// RealMe Service Element
    /// </summary>
    public class RealMeService: ConfigurationElement
    {
        /// <summary>
        /// RealMe Service name property
        /// </summary>
        [ConfigurationProperty("name", IsRequired = true, IsKey = true)]
        public string Name
        {
            get { return this["name"].ToString(); }
            set { this["name"] = value; }
        }

        /// <summary>
        /// RealMe idpEndPoint (issuer) property
        /// </summary>
        [ConfigurationProperty("idpEndPoint", IsRequired = true)]
        public string IdpEndPoint
        {
            get { return this["idpEndPoint"].ToString(); }
            set { this["idpEndPoint"] = value; }
        }
        /// <summary>
        /// RealMe authenticationType property
        /// </summary>
        [ConfigurationProperty("authenticationType", IsRequired = true)]
        public string AuthenticationType
        {
            get { return this["authenticationType"].ToString(); }
            set { this["authenticationType"] = value; }
        }
    }

    public class RealMeServiceCollection: ConfigurationElementCollection
    {
        public RealMeService this[int index]
        {
            get { return (RealMeService)BaseGet(index); }
            set
            {
                if (BaseGet(index) != null)
                {
                    BaseRemoveAt(index);
                }
                BaseAdd(index, value);
            }
        }

        public void Add(RealMeService serviceConfig)
        {
            BaseAdd(serviceConfig);
        }

        public void Clear()
        {
            BaseClear();
        }

        public void Remove(RealMeService serviceConfig)
        {
            BaseRemove(serviceConfig.Name);
        }

        public void RemoveAt(int index)
        {
            BaseRemoveAt(index);
        }

        public void Remove(string name)
        {
            BaseRemove(name);
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new RealMeService();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((RealMeService)element).Name;
        }

        public IList<RealMeService> GetRealMeServices()
        {
            var providers = new List<RealMeService>();

            foreach (RealMeService rms in this)
            {
                providers.Add(new RealMeService()
                {
                    Name = rms.Name,
                    IdpEndPoint = rms.IdpEndPoint,
                    AuthenticationType = rms.AuthenticationType,
                });
            }

            return providers;
        }

        public RealMeService GetServiceByName(string name)
        {
            var service = GetRealMeServices().FirstOrDefault(s => s.Name == name);

            if(service==null)
                throw new NoNullAllowedException(
                    string.Format("The service name {0} could not be ound in web.config.", name));

            return service;
        }
    }
}