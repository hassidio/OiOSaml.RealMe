﻿using System.Web;
using dk.nita.saml20.config;
using dk.nita.saml20.protocol.pages;
using dk.nita.saml20.ProxyClasses.protocol;
using dk.nita.saml20.Utils;

namespace OiOSaml.RealMe.Protocol
{
    public class RealMeSaml20SignonHandler : Saml20SignonHandlerProxy
    {
        /// <summary>
        /// Handle authentication request creation process to be sent to the IDP.
        /// </summary>
        protected override void SendRequest(HttpContext context)
        {
            Trace.TraceMethodCalled(GetType(), "SendRequest()");

            SetReturnUrl();

            IDPEndPoint idpEndpoint = RetrieveIDP(context);

            if (idpEndpoint == null)
            {
                //Display a page to the user where she can pick the IDP
                SelectSaml20IDP page = new SelectSaml20IDP();
                page.ProcessRequest(context);
                return;
            }

            var authnRequest = GetSaml20AuthnRequest(idpEndpoint, context);

            TransferClient(idpEndpoint, authnRequest);
        }
    }
}
