OIOSAML.NET version 1.7.13
-------------------------------------------------------------------

This software package contains a "Service Provider" implementation
of the Danish OIO Web SSO Profile V2.0.9 also known as OIOSAML 2.0.9

The software is released in open source under the Mozilla Public License version 1.1

Files contained in this distribution:

readme.txt : this file
dk.nita.saml20.zip : Source code distribution of the OIOSAML.NET toolkit version 1.7.13
dk.nita.saml20.msi : Binary distribution of the above
Net SAML2 Service Provider Framework.pdf : Documentation file
LICENSE.txt : Mozilla Public License version 1.1 text

For further information on how to install and run the 
Service Provider framework, please refer to the documentation file.
