﻿using System;
using System.Collections.Generic;
using System.Text;

namespace dk.nita.saml2.ext.brs
{
    /// <summary>
    /// Constants for the Virk BRS extension
    /// </summary>
    public class BRSConstants
    {
        public const string XML_NAMESPACE = "http://www.eogs.dk/2007/07/brs";
    }
}