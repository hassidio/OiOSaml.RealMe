An AppFabric Cache cluster must be installed and up and running.

The AppFabric Cache can be started by follwoing the steps below:

1. Open "Caching Administration Windows PowerShell" as administrator (elevated mode).
2. Run command Start-CacheCluster
